package webservice;

public class Cliente {
     
    public static void main(String[] args) {
         
    }
}
