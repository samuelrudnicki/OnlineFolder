package webservice;
   
public class Servidor {

    public static void main(String[] args) {

    }
}
